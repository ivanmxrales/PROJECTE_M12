import React from 'react'

const userconfig = () => {
  return (
    <div>userconfig</div>
  )
}

export default userconfig