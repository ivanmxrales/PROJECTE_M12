import React from 'react'

const Posts = () => {
  return (
    <div>Posts</div>
  )
}

export default Posts